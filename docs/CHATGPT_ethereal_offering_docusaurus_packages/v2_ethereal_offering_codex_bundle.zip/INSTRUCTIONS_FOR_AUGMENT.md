# INSTRUCTIONS_FOR_AUGMENT

Generated: 2025-10-12 09:28:31 UTC

Apply the patch or upload the docs folder into your repo as described.
