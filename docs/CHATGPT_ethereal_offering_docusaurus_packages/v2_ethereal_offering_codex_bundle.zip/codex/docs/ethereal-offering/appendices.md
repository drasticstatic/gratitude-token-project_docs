# Appendices, References & Augment Prompt

References: A Course in Miracles, Samurai Escape Trainer summary, TeraHash concept notes, Substack essays.
