# Gratitude Tokenomics & Economic Design

Design Principles: non-speculative utility, service-anchored issuance, time-weighted participation (inspired by TeraHash), treasury reserves for sabbath and care.
