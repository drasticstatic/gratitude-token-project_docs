# Psanctuary Ecosystem & Integrations

This project integrates ministry, recovery, and decentralized tech. Partnerships include Psanctuary Church, PIR, Bushido, Compassion Int'l, and others.
