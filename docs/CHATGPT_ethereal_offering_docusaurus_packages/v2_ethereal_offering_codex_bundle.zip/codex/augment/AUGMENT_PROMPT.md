# AUGMENT PROMPT

{
  "title": "Ethereal Offering \u2014 Augment Master Prompt",
  "generated": "2025-10-12 09:28:31 UTC",
  "instructions": [
    "Use the files in /docs/ethereal-offering as the source of truth.",
    "Expand technical architecture into epics and sprints.",
    "Generate developer README, local dev instructions, and testnet deployment steps.",
    "Generate smart contract scaffolds and Docusaurus sidebar config."
  ],
  "tone": "Hybrid: devotional yet technical-expository"
}