# Codex Building Sessions
**Focus:** Infographic, Docusaurus structure, Codex creation, patching, GitBook integration.