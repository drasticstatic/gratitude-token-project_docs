# Gratitude Token and Soulbound NFTs
**Focus:** Gratitude Token system, soulbound NFTs, DID integration, mobile UX, P2E mechanics, Aleo tokenomics.