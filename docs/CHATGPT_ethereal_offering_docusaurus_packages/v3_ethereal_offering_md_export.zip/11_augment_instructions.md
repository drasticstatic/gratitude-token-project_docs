# Augment Instructions
**Focus:** Augment parsing instructions, mapping to Docusaurus sidebar, scaffolding code tasks in JS/React/Aleo/Solidity.