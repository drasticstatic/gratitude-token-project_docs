# Psilocybin NFT Collection
**Focus:** Mushroom NFT collection: issuance schedule, DAO treasury integration, Ethereal Offering Token mechanics.