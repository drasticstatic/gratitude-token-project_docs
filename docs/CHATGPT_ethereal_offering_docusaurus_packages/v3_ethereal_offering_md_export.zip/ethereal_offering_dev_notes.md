# Ethereal Offering Dev Notes
Condensed technical focus for onboarding engineers: architecture, tokenomics, MPC, DAO, NFT/memory integration, tooling.