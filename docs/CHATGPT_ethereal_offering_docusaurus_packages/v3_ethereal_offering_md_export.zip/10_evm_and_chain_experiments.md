# EVM and Chain Experiments
**Focus:** Advanced EVM-side experiments, hybrid chains, compression techniques, performance notes.