# DEX and Arbitrage Tools
**Focus:** Arbitrage scanner, dashboard, Solidity integration, dropstab.com, Solidus agent.