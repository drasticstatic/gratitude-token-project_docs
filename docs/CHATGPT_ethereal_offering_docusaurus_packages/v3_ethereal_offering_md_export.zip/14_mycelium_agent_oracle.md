# Mycelium Agent Oracle
**Focus:** Oracle of Fruit, LLM-powered ritual intelligence, automation, personalized offerings via memory/Notion.