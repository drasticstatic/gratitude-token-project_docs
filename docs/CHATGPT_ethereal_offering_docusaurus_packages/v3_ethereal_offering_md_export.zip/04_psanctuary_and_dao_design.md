# Psanctuary and DAO Design
**Focus:** Psanctuary Church, Psychedelics in Recovery, soulbound NFTs, Gratitude Token, DAO governance.