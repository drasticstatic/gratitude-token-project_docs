# Ethereal Offering — Docusaurus Package

Generated: 2025-10-11 21:45:26 UTC

This package contains Docusaurus-ready Markdown pages for the Ethereal Offering project.
Drop the `docs/ethereal-offering` folder into your Docusaurus site's `docs` directory and update your `sidebars.js` or `sidebars.json` with the suggested config in `sidebars-suggestion.json`.

Augment Prompt is included as `docs/ethereal-offering/augment-prompt.json`.
