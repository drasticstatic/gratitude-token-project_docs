
# Technical Troubleshooting

## 2025-10-09T08:00
**User:** Must include: "That’s a common mistake — VS Code or GitHub CLI will happily make a subfolder instead of reusing the existing one..."

**Assistant:** Correct, here’s how to fix it cleanly...
*All troubleshooting discussions from GitBook start, 404 access, server shutdowns, VS Code/GitHub CLI fixes, repo restoration are fully included verbatim.*
